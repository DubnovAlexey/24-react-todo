const root = ReactDOM.createRoot(document.getElementById('root'));

const Group = () => {
    return <h1>Java 62</h1>;
}

root.render(<Group />);