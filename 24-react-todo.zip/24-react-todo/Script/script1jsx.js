const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);

const hello = <h1>Hello, world!</h1>;
root.render(hello);